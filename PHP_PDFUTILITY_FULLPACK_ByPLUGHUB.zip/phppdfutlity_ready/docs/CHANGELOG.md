# Changelog

## v1.0.0
- Initial release of PHP PDF Utility (lock/unlock/merge/split/convert/redact + unified /pdfservice API)
- Front-end modal UX with Upload + service cards
- Added size limits and MIME checks (25MB default) with JSON error handling
- Documentation for install and API usage